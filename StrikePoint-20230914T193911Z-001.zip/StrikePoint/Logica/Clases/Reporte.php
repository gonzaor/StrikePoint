<?php

class Reporte
{
private $admin;
private $tipo;
private $descripcion;
private $estado;
private $fecha;
private $comentario;

    /**
     * @param $admin
     * @param $tipo
     * @param $descripcion
     * @param $estado
     * @param $fecha
     * @param $comentario
     */
    public function __construct($admin, $tipo, $descripcion, $estado, $fecha, $comentario)
    {
        $this->admin = $admin;
        $this->tipo = $tipo;
        $this->descripcion = $descripcion;
        $this->estado = $estado;
        $this->fecha = $fecha;
        $this->comentario = $comentario;
    }

    /**
     * @return mixed
     */
    public function getAdmin()
    {
        return $this->admin;
    }

    /**
     * @param mixed $admin
     */
    public function setAdmin($admin)
    {
        $this->admin = $admin;
    }

    /**
     * @return mixed
     */
    public function getTipo()
    {
        return $this->tipo;
    }

    /**
     * @param mixed $tipo
     */
    public function setTipo($tipo)
    {
        $this->tipo = $tipo;
    }

    /**
     * @return mixed
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * @param mixed $descripcion
     */
    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $estado
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    /**
     * @return mixed
     */
    public function getFecha()
    {
        return $this->fecha;
    }

    /**
     * @param mixed $fecha
     */
    public function setFecha($fecha)
    {
        $this->fecha = $fecha;
    }

    /**
     * @return mixed
     */
    public function getComentario()
    {
        return $this->comentario;
    }

    /**
     * @param mixed $comentario
     */
    public function setComentario($comentario)
    {
        $this->comentario = $comentario;
    }
public function MostrarInfo(){

}

}