<?php

class Administrador extends Usuario
{


    public function __construct()
    {
    }

    public function ModificarComplejo(){

    }

    public function AgregarComplejo(){

    }

    public function EliminarComplejo(){

    }

    public function AgregarActividadDeportiva(){


    }

    public function ModificarActividadDeportiva(){

    }

    public function DesactivarActividad(){

    }

    public function AdministrarComplejo(){

    }

    public function DesactivarCliente(){

    }

    public function ModificarCliente(){

    }

}